/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projetoblusablusas;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class TelaUsuário extends javax.swing.JInternalFrame {

    /**
     * Creates new form TelaUsuário
     */
    public TelaUsuário() {
        initComponents();
        this.tabelaConsultaUsuario.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelaConsultaUsuario.getTableHeader().setOpaque(false);
        this.tabelaConsultaUsuario.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelaConsultaUsuario.getTableHeader().setForeground(Color.WHITE);
        this.tabelaConsultaUsuario.setRowHeight(25);
        
        this.tabelaEndereco.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelaEndereco.getTableHeader().setOpaque(false);
        this.tabelaEndereco.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelaEndereco.getTableHeader().setForeground(Color.WHITE);
        this.tabelaEndereco.setRowHeight(25);
        
        this.tabelatelefone.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        this.tabelatelefone.getTableHeader().setOpaque(false);
        this.tabelatelefone.getTableHeader().setBackground(new Color(102,0,102));
        this.tabelatelefone.getTableHeader().setForeground(Color.WHITE);
        this.tabelatelefone.setRowHeight(25);
        
        
        atualizarUsuario();
        
        
     
        
    }
public void atualizarUsuario(){
    try {
            Connection coin = ConexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT u.id_pessoa, p.nome,p.email,p.cpf,p.genero, u.situacao AS SituacaoUsuario FROM usuario u\n" +
"INNER JOIN pessoa p ON p.id_pessoa = u.id_pessoa;";

             
             
             PreparedStatement stmt = coin.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelausuario = (DefaultTableModel) this.tabelaConsultaUsuario.getModel();
            tabelausuario.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("id_pessoa"),rs.getString("nome"),rs.getString("email"),rs.getString("cpf"),rs.getString("genero"),rs.getString("SituacaoUsuario")};
                 tabelausuario.addRow(array);
                 
             }
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }  
}

public void atualizarInformaçõesPessoas(){
    
     try {
         
            String codigoUsuario = this.tabelaConsultaUsuario.getValueAt(this.tabelaConsultaUsuario.getSelectedRow(), 0).toString();
            Connection coin = ConexaoBancoDeDados.conexaoBanco();
             String sql ="SELECT cep,rua,cidade,bairro,uf,numero,situacao FROM endereco WHERE id_pessoa=?;";
             PreparedStatement stmt = coin.prepareStatement(sql);
             stmt.setString(1,codigoUsuario );
             ResultSet rs = stmt.executeQuery();
             
            DefaultTableModel tabelaendereco = (DefaultTableModel) this.tabelaEndereco.getModel();
            tabelaendereco.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("cep"),rs.getString("uf"),rs.getString("cidade"),rs.getString("bairro"),rs.getString("rua"),rs.getString("numero"),rs.getString("situacao")};
                 tabelaendereco.addRow(array); 
             }
             
             sql ="SELECT ddd,numero,tipo,situacao FROM telefone WHERE id_pessoa = ?;";
             stmt = coin.prepareStatement(sql);
             stmt.setString(1,codigoUsuario );
             rs = stmt.executeQuery();
             
            DefaultTableModel tabelatelefone = (DefaultTableModel) this.tabelatelefone.getModel();
            tabelatelefone.setNumRows(0);
             while(rs.next()){
                 Object[] array ={rs.getString("ddd"),rs.getString("numero"),rs.getString("tipo"),rs.getString("situacao")};
                 tabelatelefone.addRow(array); 
             }
             
             
             
             coin.close();
             stmt.close();
             rs.close();
            
        } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } 
    
    
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tabelaConsultaUsuario = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        pesquisausuario = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaEndereco = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabelatelefone = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Consultas de Usuários");
        setMinimumSize(new java.awt.Dimension(700, 400));

        tabelaConsultaUsuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome", "Email", "CPF", "Gênero", "Situação Usuário"
            }
        ));
        tabelaConsultaUsuario.setSelectionBackground(new java.awt.Color(153, 0, 153));
        tabelaConsultaUsuario.setSelectionForeground(new java.awt.Color(255, 255, 255));
        tabelaConsultaUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaConsultaUsuarioMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabelaConsultaUsuario);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("         Pesquisar CPF : ");

        pesquisausuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pesquisausuarioKeyPressed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(102, 0, 102));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("    Consulta de Usuários");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1084, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Usuário");

        jButton1.setText("Usuários Deletadas");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        tabelaEndereco.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CEP", "Estado", "Cidade", "Bairro", "Rua", "Número", "Situação"
            }
        ));
        tabelaEndereco.setSelectionBackground(new java.awt.Color(153, 0, 153));
        tabelaEndereco.setSelectionForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(tabelaEndereco);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Endereço do Usuário");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 896, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(64, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57))
        );

        jTabbedPane1.addTab("Endereço", jPanel2);

        tabelatelefone.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "DD", "Telefone", "Tipo", "Situação do número"
            }
        ));
        tabelatelefone.setSelectionBackground(new java.awt.Color(153, 0, 153));
        tabelatelefone.setSelectionForeground(new java.awt.Color(255, 255, 255));
        jScrollPane3.setViewportView(tabelatelefone);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Endereço do Usuário");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Telefone do Usuário");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 808, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(147, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(424, 424, 424)
                    .addComponent(jLabel5)
                    .addContainerGap(425, Short.MAX_VALUE)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel6)
                .addGap(27, 27, 27)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(157, 157, 157)
                    .addComponent(jLabel5)
                    .addContainerGap(158, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Telefone", jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel1)
                        .addGap(6, 6, 6)
                        .addComponent(pesquisausuario, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(62, 62, 62)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 988, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 988, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(94, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel1))
                    .addComponent(pesquisausuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
          
        UsuárioDeletados ud = new UsuárioDeletados(null,true);
        ud.setVisible(true);
        
        
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tabelaConsultaUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaConsultaUsuarioMouseClicked
      atualizarInformaçõesPessoas();
    }//GEN-LAST:event_tabelaConsultaUsuarioMouseClicked

    private void pesquisausuarioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisausuarioKeyPressed
           
        try {
            Connection coin = ConexaoBancoDeDados.conexaoBanco();
            String sql = "SELECT u.id_pessoa, p.nome,p.email,p.cpf,p.genero, u.situacao AS SituacaoUsuario FROM usuario u\n" +
"INNER JOIN pessoa p ON p.id_pessoa = u.id_pessoa WHERE p.cpf LIKE '%"+this.pesquisausuario.getText()+"%';";
            PreparedStatement stmt = coin.prepareStatement(sql);
            DefaultTableModel tbpesquisa = ( DefaultTableModel) this.tabelaConsultaUsuario.getModel();
            tbpesquisa.setNumRows(0);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                 Object[] array ={rs.getString("id_pessoa"),rs.getString("nome"),rs.getString("email"),rs.getString("cpf"),rs.getString("genero"),rs.getString("SituacaoUsuario")};
                 tbpesquisa.addRow(array);
            }
            rs.close();
            stmt.close();
            coin.close();
            
             } catch (SQLException ex) {
            System.getLogger(Home.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } 
        
    }//GEN-LAST:event_pesquisausuarioKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField pesquisausuario;
    private javax.swing.JTable tabelaConsultaUsuario;
    private javax.swing.JTable tabelaEndereco;
    private javax.swing.JTable tabelatelefone;
    // End of variables declaration//GEN-END:variables
}
