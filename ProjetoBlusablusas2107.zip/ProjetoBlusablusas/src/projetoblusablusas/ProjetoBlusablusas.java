/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projetoblusablusas;


public class ProjetoBlusablusas {

   
    public static void main(String[] args) {
        Home tl = new Home();
        tl.setVisible(true);
       
    }
    
}
